# +OneFB
+OneFB will add +1 button below each FB post. All articles recommended by +1 button will be appeared on Google Plus profile.

This Chrome extention will add "Plus One" Button below each Facebook post. All articles recommended by +1 button will be appeared on Google Plus profile.

For more information about "Plus One" Button: http://goo.gl/ccuoP

Technical supports: https://plus.google.com/u/0/+HoaiTuongNGUYEN

TRACK CHANGES:

(03/02/2011) Adapt to new +One button version.

(18/07/2011) Extract external link instead of FB-permanent link (privacy reason).
